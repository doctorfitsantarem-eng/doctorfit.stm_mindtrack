import streamlit as st
import sqlite3, io
from datetime import datetime
import pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors

DB_PATH = "data.db"

def init_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS evaluations (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 name TEXT, age INTEGER, email TEXT, phone TEXT, turma TEXT,
                 a1 INTEGER,a2 INTEGER,a3 INTEGER,a4 INTEGER,a5 INTEGER,
                 b1 INTEGER,b2 INTEGER,b3 INTEGER,b4 INTEGER,b5 INTEGER,
                 c1 INTEGER,c2 INTEGER,c3 INTEGER,c4 INTEGER,
                 obs TEXT, created_at TEXT
                 )""")
    conn.commit()
    return conn

def save_evaluation(conn, data):
    c = conn.cursor()
    c.execute("""INSERT INTO evaluations
                 (name,age,email,phone,turma,
                  a1,a2,a3,a4,a5,
                  b1,b2,b3,b4,b5,
                  c1,c2,c3,c4,obs,created_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (data['name'], data['age'], data['email'], data['phone'], data['turma'],
               data['autor'][0],data['autor'][1],data['autor'][2],data['autor'][3],data['autor'][4],
               data['autoef'][0],data['autoef'][1],data['autoef'][2],data['autoef'][3],data['autoef'][4],
               data['emoc'][0],data['emoc'][1],data['emoc'][2],data['emoc'][3],
               data['obs'], data['created_at']))
    conn.commit()
    return c.lastrowid

def score_and_classify(responses):
    autor = sum(responses['autorreg'])
    autoef = sum(responses['autoef'])
    emoc = sum(responses['emocional'])
    def classify_autor(x):
        if x >= 20: return "Alta autorregulação"
        if x >= 15: return "Moderada"
        if x >= 10: return "Baixa"
        return "Necessita apoio"
    def classify_autoef(x):
        if x >= 20: return "Alta autoeficácia"
        if x >= 15: return "Confiança moderada"
        if x >= 10: return "Confiança baixa"
        return "Necessita suporte próximo"
    def classify_emoc(x):
        if x >= 16: return "Boa regulação emocional"
        if x >= 10: return "Regulação moderada"
        return "Necessita desenvolver estratégias"
    return {
        'autorreg_score': autor,
        'autorreg_class': classify_autor(autor),
        'autoef_score': autoef,
        'autoef_class': classify_autoef(autoef),
        'emoc_score': emoc,
        'emoc_class': classify_emoc(emoc)
    }

def generate_pdf_bytes(record, scores, logo_path=None):
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4,
                            rightMargin=2*cm,leftMargin=2*cm,topMargin=2*cm,bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('title', parent=styles['Heading1'], alignment=1, textColor=colors.HexColor("#0D9488"))
    normal = styles['Normal']
    story = []
    if logo_path:
        try:
            story.append(Image(logo_path, width=6*cm, height=2*cm))
            story.append(Spacer(1,12))
        except Exception:
            pass
    story.append(Paragraph("DoctorFit Santarém", title_style))
    story.append(Spacer(1,6))
    story.append(Paragraph("Relatório Psicossocial – Avaliação Inicial (pré-início)", styles['Heading2']))
    story.append(Spacer(1,12))
    story.append(Paragraph(f"<b>Nome:</b> {record['name']}", normal))
    story.append(Paragraph(f"<b>Idade:</b> {record['age']}   <b>Turma/horário:</b> {record['turma']}", normal))
    story.append(Paragraph(f"<b>Data:</b> {record['created_at']}", normal))
    story.append(Spacer(1,12))
    story.append(Paragraph(f"<b>Autorregulação (5-25):</b> {scores['autorreg_score']} — {scores['autorreg_class']}", normal))
    story.append(Paragraph(f"<b>Autoeficácia (5-25):</b> {scores['autoef_score']} — {scores['autoef_class']}", normal))
    story.append(Paragraph(f"<b>Gestão emocional (4-20):</b> {scores['emoc_score']} — {scores['emoc_class']}", normal))
    story.append(Spacer(1,12))
    story.append(Paragraph("<b>Interpretação breve:</b>", styles['Heading3']))
    interp = []
    interp.append(f"Autorregulação: {scores['autorreg_class']}. Recomenda-se trabalhar metas e rotinas simples para fortalecer consistência.")
    interp.append(f"Autoeficácia: {scores['autoef_class']}. Reforços positivos e pequenas conquistas aumentam a confiança.")
    interp.append(f"Gestão emocional: {scores['emoc_class']}. Estratégias de regulação (respiração, atividade física leve, apoio social) são indicadas.")
    for p in interp:
        story.append(Paragraph(p, normal))
        story.append(Spacer(1,6))
    story.append(Spacer(1,8))
    story.append(Paragraph("<b>Observações do treinador:</b>", styles['Heading3']))
    story.append(Paragraph(record.get('obs','-'), normal))
    story.append(Spacer(1,16))
    story.append(Paragraph("DoctorFit Santarém — Treine o corpo, fortaleça a mente.", styles['Normal']))
    doc.build(story)
    buffer.seek(0)
    return buffer.read()

st.set_page_config(page_title="DoctorFit MindTrack — Avaliação Inicial", layout="centered")
st.markdown("<h1 style='color:#0D9488'>DoctorFit MindTrack</h1>", unsafe_allow_html=True)
st.markdown("**Avaliação Psicossocial – Pré-início do Programa**")
st.write("Preencha os dados do avaliado e responda os itens com sinceridade. Esta avaliação ajuda a personalizar o suporte inicial.")

conn = init_db()

with st.form("form_av"):
    st.subheader("Dados pessoais e turma")
    name = st.text_input("Nome completo", max_chars=80)
    age = st.number_input("Idade", min_value=14, max_value=100, value=30)
    email = st.text_input("E-mail (opcional)")
    phone = st.text_input("Telefone (opcional)")
    turma = st.text_input("Turma / Horário (ex: Seg 18:00)")
    st.subheader("Autorregulação (1 = nada → 5 = totalmente)")
    a1 = st.slider("Costumo planejar antes de começar algo novo.", 1,5,3,key="a1")
    a2 = st.slider("Tenho dificuldade em manter um plano quando me desanimo.",1,5,3,key="a2")
    a3 = st.slider("Penso nas consequências antes de agir.",1,5,3,key="a3")
    a4 = st.slider("Quando falho em algo, tento entender o que posso melhorar.",1,5,3,key="a4")
    a5 = st.slider("Tenho facilidade em organizar minha rotina quando defino um objetivo.",1,5,3,key="a5")
    st.subheader("Autoeficácia (1 = nada → 5 = totalmente)")
    b1 = st.slider("Acredito que consigo começar uma rotina de treinos mesmo se estiver cansado.",1,5,3,key="b1")
    b2 = st.slider("Sei que posso mudar meus hábitos, mesmo que leve tempo.",1,5,3,key="b2")
    b3 = st.slider("Acredito que sou capaz de lidar com imprevistos e manter o foco.",1,5,3,key="b3")
    b4 = st.slider("Mesmo em dias difíceis, sei que sou capaz de treinar.",1,5,3,key="b4")
    b5 = st.slider("Sinto que posso mudar meus hábitos se eu realmente quiser.",1,5,3,key="b5")
    st.subheader("Gestão emocional (1 = nada → 5 = totalmente)")
    c1 = st.slider("Consigo identificar o que estou sentindo antes de agir impulsivamente.",1,5,3,key="c1")
    c2 = st.slider("Quando fico estressado, encontro formas saudáveis de relaxar (ex.: treinar, conversar).",1,5,3,key="c2")
    c3 = st.slider("Tento ver o lado positivo das situações difíceis.",1,5,3,key="c3")
    c4 = st.slider("Quando algo me frustra, não deixo que isso afete minha alimentação ou treino.",1,5,3,key="c4")
    obs = st.text_area("Observações (treinador)", height=120)
    submitted = st.form_submit_button("Salvar avaliação e gerar relatório PDF")
    if submitted:
        record = {
            'name': name, 'age': age, 'email': email, 'phone': phone, 'turma': turma,
            'autor':[a1,a2,a3,a4,a5],
            'autoef':[b1,b2,b3,b4,b5],
            'emoc':[c1,c2,c3,c4],
            'obs': obs,
            'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        rowid = save_evaluation(conn, record)
        scores = score_and_classify({'autorreg':record['autor'],'autoef':record['autoef'],'emocional':record['emoc']})
        pdf_bytes = generate_pdf_bytes(record, scores, logo_path=None)
        st.success(f"Avaliação salva (ID {rowid}).")
        st.download_button("Baixar relatório em PDF", data=pdf_bytes, file_name=f"{name}_relatorio_psicossocial.pdf", mime='application/pdf')
        st.write("Resultado rápido:")
        st.write(f"Autorregulação: {scores['autorreg_score']} — {scores['autorreg_class']}")
        st.write(f"Autoeficácia: {scores['autoef_score']} — {scores['autoef_class']}")
        st.write(f"Gestão emocional: {scores['emoc_score']} — {scores['emoc_class']}")
        st.info("O relatório foi gerado com a identidade DoctorFit (cores e linguagem).")
